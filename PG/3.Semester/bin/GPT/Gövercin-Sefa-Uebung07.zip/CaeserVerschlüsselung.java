import java.util.Scanner;

public class CaeserVerschl�sselung {

	public static void main(String[] args) {
		Scanner eingabe = new Scanner(System.in);
		System.out.print("Encryption Code: ");
		String message = eingabe.nextLine();
		System.out.println("==========ENCRYPTION==========");
		encrypt(message);

	}

	public static void encrypt(String m) {
		String encryptMessage ="";
		for (int i = 0; i <= m.length()-1; i++) {
			char c = m.charAt(i);
			encryptMessage+=(char) ((c+3-'a')%('z'-'a')+'a');
		}
		System.out.println(encryptMessage);
	}

}
