public class Umdreher {
	public static void main(String[] args){
		System.out.println(umdrehenIterativ(args[0]));
		System.out.println(umdrehenRekursiv(args[0]));
	}
	public static String umdrehenIterativ(String s){
		String ergebnis="";
		for(int i = s.length()-1; i>=0; i--){
			System.out.print(s.charAt(i));
		}
		return ergebnis;
	}
	public static String umdrehenRekursiv(String s){
		if(s.length() == 0)
			return "";
		else{
			String c = s.substring(s.length()-1, s.length());
			return c+=umdrehenRekursiv(s.substring(0,s.length()-1));
		}
			
	}
}
